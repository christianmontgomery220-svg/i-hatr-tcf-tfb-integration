I-HATR Integration Module (v1.0.1)
See documentation.
